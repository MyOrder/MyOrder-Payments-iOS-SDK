//
//  MOPaymentProviderCell.h
//  MyOrder
//
//  Created by Angel Garcia on 5/28/13.
//
//

#import <UIKit/UIKit.h>
#import "MOPaymentProviderProtocol.h"

@interface MOPaymentProviderCell : UITableViewCell

@property (nonatomic, strong) id<MOPaymentProviderProtocol> provider;
@property (nonatomic, assign) BOOL isExpanded;

+ (CGFloat)heightOfCell:(BOOL)isExpanded;

@end
