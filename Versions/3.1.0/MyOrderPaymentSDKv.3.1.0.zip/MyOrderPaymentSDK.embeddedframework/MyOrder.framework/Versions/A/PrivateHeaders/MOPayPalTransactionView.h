//
//  MOPayPalTransactionView.h
//  MyOrder
//
//  Created by Angel Garcia on 5/31/13.
//
//

#import "MOTransactionView.h"

@interface MOPayPalTransactionView : MOTransactionView

@end
