//
//  MOReceiptItemCell.h
//  MyOrder
//
//  Created by Angel Garcia on 6/18/13.
//  Copyright (c) 2013 Xaton. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MOReceiptOrderItem;

@interface MOReceiptItemCell : UITableViewCell

- (void)configureWithOrderItem:(MOReceiptOrderItem *)orderItem;

+ (CGFloat)heightOfCellWithReceiptOrderItem:(MOReceiptOrderItem *)product width:(CGFloat)width;

@end

@interface MOReceiptFuelCell : UITableViewCell
- (void)configureWithImage:(UIImage*)image title:(NSString*)title subtitle:(NSString*)subtitle amount:(NSNumber*)amount;
@end