//
//  NSURL+MOUtils.h
//  MyOrder
//
//  Created by Angel Garcia on 11/11/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (MOUtils)

+ (NSURL *)MO_URLWithPath:(NSString *)path;
+ (NSURL *)MO_MyOrderURLWithPath:(NSString *)path;

@end
