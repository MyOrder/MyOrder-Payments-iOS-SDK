//
//  MOPaymentMethodsCell.h
//  MyOrder
//
//  Created by Angel Garcia on 5/29/13.
//
//

#import <UIKit/UIKit.h>
#import "MOPaymentProviderProtocol.h"

typedef void(^MOPaymentMethodBlock)(id<MOPaymentProviderProtocol> provider);

@interface MOPaymentMethodsCell : UITableViewCell

@property (nonatomic, strong) id<MOPaymentProviderProtocol> provider;
@property (nonatomic, copy) MOPaymentMethodBlock onMethodSelected;
@property (nonatomic, assign) BOOL isWalletOperation;

+ (CGFloat)heightOfCell;

@end
