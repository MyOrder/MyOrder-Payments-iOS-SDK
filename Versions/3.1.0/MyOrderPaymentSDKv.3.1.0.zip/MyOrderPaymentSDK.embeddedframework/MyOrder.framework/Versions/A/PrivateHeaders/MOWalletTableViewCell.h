//
//  MOWalletTableViewCell.h
//  MyOrder
//
//  Created by Angel Garcia on 20/03/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MOWalletTableViewCell : UITableViewCell

@property (nonatomic,getter=isEnabled) BOOL enabled;
@property (nonatomic) BOOL expandable;
@property (nonatomic, copy) dispatch_block_t onIncreaseSpendingLimitTapped;

- (void)setWalletAmount:(NSNumber *)walletAmount;

- (void)setRemainingSpendAmount: (NSNumber *)remainingSpendAmount;
- (void)setAnnualSpendAmount: (NSNumber *)annualSpendAmount;
- (void)expanded:(BOOL)expanded;
+ (CGFloat)heightOfCell:(BOOL)isExpanded;


@end
