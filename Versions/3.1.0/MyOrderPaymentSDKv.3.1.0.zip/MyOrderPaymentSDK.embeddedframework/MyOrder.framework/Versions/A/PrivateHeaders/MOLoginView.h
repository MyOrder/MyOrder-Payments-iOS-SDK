//
//  MOLoginView.h
//  MyOrder
//
//  Created by Angel Garcia on 5/27/13.
//
//

#import <UIKit/UIKit.h>

typedef void(^MOLoginBlock)(NSString *username);

@interface MOLoginView : UIScrollView

- (id)initWithUsername:(NSString *)username;

@property (nonatomic, copy) MOLoginBlock onLogin;
@property (nonatomic, copy) MOLoginBlock onRegister;
@property (nonatomic, copy) dispatch_block_t dismissAction;
@property (nonatomic, assign) BOOL showDismissButton;

@end
