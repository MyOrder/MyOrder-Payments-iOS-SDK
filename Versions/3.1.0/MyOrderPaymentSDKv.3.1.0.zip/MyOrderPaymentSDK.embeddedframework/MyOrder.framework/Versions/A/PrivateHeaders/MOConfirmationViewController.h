//
//  MOConfirmationViewController.h
//  MyOrder
//
//  Created by Angel Garcia on 5/31/13.
//
//

#import <UIKit/UIKit.h>
#import "MOViewController.h"

typedef NS_ENUM(NSInteger, MOConfirmationViewControllerPurpose) {
    MOConfirmationViewControllerPurposeGeneric = 0,
    MOConfirmationViewControllerPurposeEmail,
    MOConfirmationViewControllerPurposePhone
};

@interface MOConfirmationViewController : MOViewController

@property (nonatomic, copy) void (^completionBlock)(MOConfirmationViewController *controller, NSString *confirmationValue);
@property (nonatomic, copy) void (^cancelationBlock)(MOConfirmationViewController *controller);
@property (nonatomic, copy) void (^resendBlock)(MOConfirmationViewController *controller);


@property (nonatomic, readonly) MOConfirmationViewControllerPurpose purpose;

- (id)initWithPurpose:(MOConfirmationViewControllerPurpose)purpose;

@end
