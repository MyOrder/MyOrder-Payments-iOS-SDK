//
//  MOTextField.h
//  MyOrder
//
//  Created by Angel Garcia on 5/27/13.
//
//

#import <UIKit/UIKit.h>

@protocol MOTextFieldBackSpcaeDelegate <NSObject>
@optional
- (void)textFieldDidTappedBackSpace:(UITextField *)textField;
@end

@interface MOTextField : UITextField

//@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) UITextField *nextTextField;
@property (nonatomic, assign) CGFloat leftPadding;
@property (nonatomic) CGFloat leftViewYOffset;
@property (nonatomic, assign) id<MOTextFieldBackSpcaeDelegate> backSpaceDelegate;

- (void)sizeToFitCell:(UITableViewCell *)cell;

@end
