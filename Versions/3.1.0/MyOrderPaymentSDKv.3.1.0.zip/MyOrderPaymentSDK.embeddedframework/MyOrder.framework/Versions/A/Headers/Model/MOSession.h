//
//  MOSession.h
//  MyOrderApp
//
//  Created by Angel Garcia on 24/01/14.
//  Copyright (c) 2014 MyOrder.nl. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Const in customerPhoneStatus and customerEmailStatus when user is anonymous
 */
extern const NSString *MOSessionCustomerStatusNotRegistered;
/**
 * Const in customerPhoneStatus and customerEmailStatus when user is not verified
 */
extern const NSString *MOSessionCustomerStatusNotVerified;
/**
 * Const in customerPhoneStatus and customerEmailStatus when user is verified
 */
extern const NSString *MOSessionCustomerStatusVerified;
/**
 * Const in customerPhoneStatus and customerEmailStatus when status is unknown
 */
extern const NSString *MOSessionCustomerStatusUnknown;




@interface MOSession : NSObject<NSCoding>

@property (nonatomic, copy) NSString *username;
@property (nonatomic, copy) NSString *sessionKey;
@property (nonatomic, copy) NSString *customerId;
@property (nonatomic, copy) NSString *customerPhoneStatus;
@property (nonatomic, copy) NSString *customerEmailStatus;
@property (nonatomic, copy) NSString *customerEmailAddress;
@property (nonatomic, copy) NSString *customerPhone;
@property (nonatomic, copy) NSString *deviceId;
@property (nonatomic, copy) NSString *moSessionId;

@property (nonatomic, strong) NSDate *sessionDate;
@property (nonatomic, strong) NSDate *lastLoggedIn;


- (BOOL)isValid;
- (BOOL)isAnonymous;
- (BOOL)isLoggedIn;
- (BOOL)isVerified;
- (BOOL)isEmailVerified;
- (BOOL)isPhoneVerified;


@end


@interface MOSession (Mapping)
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
- (void)updateVerificationStatusWithDictionary:(NSDictionary*)dictionary;
@end

@interface MOSession (Deprecated)
- (instancetype)initWithMoSession:(NSString *)moSession andPhone:(NSString *)phone __deprecated_msg("Only for usage on V1 methods");
- (BOOL)isV1Session;
@end
