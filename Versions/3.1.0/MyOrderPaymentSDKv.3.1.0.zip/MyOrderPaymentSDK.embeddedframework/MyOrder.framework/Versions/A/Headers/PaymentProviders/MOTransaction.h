//
//  MOIdealTransaction.h
//  MyOrder
//
//  Created by Angel Garcia on 5/22/13.
//
//

#import <Foundation/Foundation.h>
#import "MOTransactionProtocol.h"
#import "MOPaymentProviderProtocol.h"

/* Generic transaction that all MyOrder providers extend. Do not use directly, treat it as an abstract class providing convenience methods */
@interface MOTransaction : NSObject<MOTransactionProtocol>

@property (nonatomic, assign) MOTransactionStatus status;
@property (nonatomic, copy) NSString *transactionDescription;


/** Transaction ID */
@property (nonatomic, copy) NSString *transactionId;

/** Return url to use on the external party service as callback */
@property (nonatomic, copy) NSString *returnUrl;


@property (nonatomic, copy) MOPluginBlock onSuccessBlock;
@property (nonatomic, copy) MOPluginErrorBlock onErrorBlock;

- (instancetype)initWithProvider:(id<MOPaymentProviderProtocol>)provider;
- (void)prepareOrderForPayment:(MOPluginBlock)block error:(MOPluginErrorBlock)errorBlock;
- (void)handleStatusResponse:(NSDictionary *)params;

@end
