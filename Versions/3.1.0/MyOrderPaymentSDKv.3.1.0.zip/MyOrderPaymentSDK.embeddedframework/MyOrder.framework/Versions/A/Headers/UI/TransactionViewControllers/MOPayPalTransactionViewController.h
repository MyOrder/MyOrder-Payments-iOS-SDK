//
//  MOPayPalTransactionViewController.h
//  MyOrder
//
//  Created by Taras Kalapun on 5/30/13.
//
//

#import "MOTransactionViewController.h"

@interface MOPayPalTransactionViewController : MOTransactionViewController

@end
