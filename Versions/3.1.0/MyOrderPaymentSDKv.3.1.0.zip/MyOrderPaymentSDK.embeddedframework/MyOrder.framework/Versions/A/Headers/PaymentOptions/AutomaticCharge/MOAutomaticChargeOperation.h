//
//  MOAutomaticChargeOperation.h
//  MyOrder
//
//  Created by Angel Garcia on 06/05/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MOPaymentOperation.h"
#import "MOWalletMandate.h"

/**
 *  Sets automatic charge properties for the wallet account. Note that this operation
 *  sometimes requires a wallet mandate to be approved before verification
 */
@interface MOAutomaticChargeOperation : MOPaymentOperation

@property (nonatomic, copy) NSString *bankAccount;
@property (nonatomic, copy) NSNumber *monthly;
@property (nonatomic, strong) NSNumber *amount;
@property (nonatomic, assign) BOOL active;
@property (nonatomic, strong) MOWalletMandate *mandate;

/**
 *  Verifies the mandate started on the operation execution
 *
 *  @param completionBlock Completion block called on success
 *  @param errorBlock      Error block if fails
 */
- (void)verifyMandateOnCompletion:(MOOperationBlock)completionBlock onError:(MOOperationErrorBlock)errorBlock;

- (void)saveWalletAccountChangesOnCompletion:(MOOperationBlock)completionBlock onError:(MOOperationErrorBlock)errorBlock;

- (void)signWithImage:(UIImage*)image onCompletion:(MOOperationBlock)completionBlock onError:(MOOperationErrorBlock)errorBlock;

@end
