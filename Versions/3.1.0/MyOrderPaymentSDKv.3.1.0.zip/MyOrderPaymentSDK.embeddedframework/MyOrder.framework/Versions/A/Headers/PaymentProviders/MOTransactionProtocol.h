//
//  MOTransactionProtocol.h
//  MyOrder
//
//  Created by Angel Garcia on 22/04/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MOOrder.h"

@protocol MOTransactionProtocol;
@protocol MOPaymentProviderProtocol;

typedef void(^MOProviderBlock)(id<MOPaymentProviderProtocol>provider);
typedef void(^MOProviderErrorBlock)(id<MOPaymentProviderProtocol>provider, NSError *error);
typedef void(^MOPluginBlock)(id<MOTransactionProtocol>plugin);
typedef void(^MOPluginErrorBlock)(id<MOTransactionProtocol>plugin, NSError *error);

typedef enum {
    MOTransactionStatusNotStarted,
    MOTransactionStatusInProgress,
    MOTransactionStatusConfirmed,
    MOTransactionStatusFinished,
    MOTransactionStatusCanceled,
    MOTransactionStatusError,
} MOTransactionStatus;


/**
 *  All Transaction providers must implement this protocol.
 *  Transactions are always designed in a 2-step process, even if some of them can be performed in a single step. This abstraction provides
 *  a common scenario for all of them, no matter of the internal implementation details. The flow is as follows:
 *  1. Create transaction and assign order/wallet amount
 *  2. Call placeOrder/fillWallet methods with confirmation, completion and error blocks
 *  3. Confirmation block is executed, call `confirm` to proceed if everything is ready. Some transactions might require additional steps like opening a browser at this step with an external URL (like iDeal)
 *  4. Success/error block executed with transaction detail and error
 */
@protocol MOTransactionProtocol <NSObject>


/**
 The payment provider used to create the transaction
 */
@property (nonatomic, weak) id<MOPaymentProviderProtocol> paymentProvider;

/**
 The ammount to charge in a wallet operation in euros
 */
@property (nonatomic, assign) double walletAmmount;

/**
 MOOrder to use for placing order. Required when placeOrder method called
 */
@property (nonatomic, strong) MOOrder *order;


/**
 Start payment transaction to fill your wallet. (ChargeXXX)
 @param confirmationBlock Block that will be called on intermediate process (confirmation)
 @param block Sucess Block
 @param errorBlock Error Block
 */
- (void)fillWalletOnConfirmation:(MOPluginBlock)confirmationBlock onSuccess:(MOPluginBlock)block error:(MOPluginErrorBlock)errorBlock;

/**
 Start payment transaction with MOOrder object to make a payment (placeOrder)
 @param confirmationBlock Block that will be called on intermediate process (confirmation)
 @param block Sucess Block
 @param errorBlock Error Block
 */
- (void)placeOrderOnConfirmation:(MOPluginBlock)confirmationBlock onSuccess:(MOPluginBlock)block error:(MOPluginErrorBlock)errorBlock;

/**
 Confirms the transaction in the two phase payment methods
 */
- (void)confirm;

/**
 Cancels the transaction in any moment
 */
- (void)cancel;

/**
 Retrieves the current state
 @return status of the transaction
 */
- (MOTransactionStatus)status;

/**
 Returns a BOOL indicating if the URL has been handled by the transaction. By default returns NO.
 @param url NSURL to handle.
 @param sourceApplication origin application
 @returns BOOL YES if the URL has been handled
 */
- (BOOL)handleURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication;


/** Check with server side the current transaction status and refreshes internally
 @param block Success block
 @param errorBlock Error block
 */
- (void)loadStatusOnSuccess:(MOPluginBlock)block error:(MOPluginErrorBlock)errorBlock;


@optional

/**
 Some transactions might want to have an extra description. For example iDeal can append the merchant name to it.
 */
@property (nonatomic, copy) NSString *transactionDescription;

@end
