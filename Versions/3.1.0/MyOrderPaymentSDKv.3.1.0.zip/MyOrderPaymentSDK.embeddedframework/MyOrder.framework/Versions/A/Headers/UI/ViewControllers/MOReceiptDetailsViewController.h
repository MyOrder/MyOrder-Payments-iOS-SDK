//
//  MOReceiptDetailsViewController.h
//  MyOrder
//
//  Created by Taras Kalapun on 6/10/13.
//  Copyright (c) 2013 Xaton. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MOViewController.h"
@class MOReceipt;
@class MOReceiptOrderItem;

@interface MOReceiptDetailsViewController : MOViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView *view;
@property (nonatomic, strong) MOReceipt *receipt;
@property (nonatomic, strong) NSDictionary *fuelOrderInfo;

//Override if custom header wanted
- (UIView *)tableHeaderViewForTable:(UITableView *)tableView;
- (void)openMerchant;
- (void)openOrderItem:(MOReceiptOrderItem *)item;

@end
