//
//  MOWithdrawFromWalletOperation.h
//  MyOrder
//
//  Created by Angel Vasa on 7/10/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import "MyOrder.h"


/**
 *  Performs a wallet withdraw to return money to the user's bank account. This operation requires confirmation of SMS code
 */
@interface MOWithdrawFromWalletOperation : MOPaymentOperation

@property (atomic, assign) CGFloat amount;

@end
