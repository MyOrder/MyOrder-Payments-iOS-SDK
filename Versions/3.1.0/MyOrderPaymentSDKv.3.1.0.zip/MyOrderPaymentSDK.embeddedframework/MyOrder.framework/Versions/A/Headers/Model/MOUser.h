//
//  MOUser.h
//  MyOrder
//
//  Created by Angel Vasa on 31/08/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MOBetaUser : NSObject

@property (nonatomic) BOOL suggestion; // smart suggestions feature

@end

@interface MOUser : NSObject

@property (nonatomic, strong) NSArray *addresses;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *mobilePhone;
@property (nonatomic, strong) NSString *dateOfBirth;
@property (nonatomic, strong) MOBetaUser *betaUser;

-(id)initWithDictionary:(NSDictionary *)dictionary;

@end


@interface MOAddresses : NSObject

@property (nonatomic, strong) NSString *identifier;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *number;
@property (nonatomic, strong) NSString *postCode;
@property (nonatomic, strong) NSString *street;

-(id)initWithDictionary:(NSDictionary *)dictionary;

@end
