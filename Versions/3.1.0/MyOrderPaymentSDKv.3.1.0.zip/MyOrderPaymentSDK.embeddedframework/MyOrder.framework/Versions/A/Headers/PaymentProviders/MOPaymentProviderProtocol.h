//
//  MOPaymentProvider.h
//  MyOrder
//
//  Created by Angel Garcia on 22/04/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MOTransaction.h"
#import "MOSession.h"

/**
 *  All payments providers must implement this protocol. MyOrder class will look on app bundle classes implementing this protocol to
 *  automatically load them on startup as any other MyOrder payment provider.
 */
@protocol MOPaymentProviderProtocol <NSObject>

/**
 Returns the provider type
 @return String with provider name (ex: PAYPAL)
 */
- (NSString *)providerType;

/**
 *  Set the provider description
 *
 *  @param providerDescription String with provider description
 */
- (void)setProviderDescription:(NSString *)providerDescription;

/**
 Returns the provider description details
 @return string with an explanation of the provider to be displayed in provider list
 */
- (NSString *)providerDescription;

/**
 Returns an array of supported MyOrder versions
 @return Array of versionIdentifiers. Example @[@"V1", @"V2"]
 */
- (NSArray *)supportedVersions;

/**
 Create a new transaction for the payment provider. Do not call this
 directly. It is called from MyOrder class when new transaction is requested
 @returns New transaction instance
 */
- (id<MOTransactionProtocol>)newTransaction;

/**
 Check if the provider is the one related to the wallet. Only one provider at a time
 can be loaded with this property to YES
 @return YES if the provider is the wallet manager
 */
- (BOOL)isWalletProvider;

/**
 Set wallet support.
 */
- (void)setWalletTransactionsSupport:(BOOL)isSupported;

/**
 Check for wallet support.
 @return YES if the provider can be used to fill the wallet
 */
- (BOOL)allowsWalletTransactions;

/**
 Set payments support.
 */
- (void)setOrderTransactionsSupport:(BOOL)isSupported;

/**
 Check for payments support.
 @return YES if the provider can be used to pay orders
 */
- (BOOL)allowsOrderTransactions;

/**
 @return Returns a number that will be used in the payment list as sorting index
 */
- (NSInteger)priority;

/**
 Check if the provider requires to perform an account (email) verification based on the
 session information and order provided.
 @return YES if the provider needs to verify the email first
 */
- (BOOL)requiresVerificationWithSession:(MOSession *)session order:(MOOrder *)order;


@end

