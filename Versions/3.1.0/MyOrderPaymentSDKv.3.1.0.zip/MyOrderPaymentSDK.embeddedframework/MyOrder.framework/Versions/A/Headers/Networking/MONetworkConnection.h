//
//  MONetworkConnection.h
//  MyOrder
//
//  Created by Angel Garcia on 16/03/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyOrder.h"

@class MONetworkConnection;

typedef void (^MONetworkConnectionHandler) (MONetworkConnection *connection);
typedef void (^MONetworkConnectionSuccessHandler) (id result, MONetworkConnection *connection);
typedef void (^MONetworkConnectionErrorHandler) (NSError *error, MONetworkConnection *connection);
typedef void (^MOMapperCompletionHandler) (id results, NSError *error);

@protocol MOMapperProtocol <NSObject>
- (void)mapDataFromConnection:(MONetworkConnection *)connection completionHandler:(MOMapperCompletionHandler)completionHandler;
@end


@protocol MONetworkConnectionRequestFactory <NSObject>

- (NSString *)sessionId;
- (NSURL *)baseURL;
- (NSURLRequest *)requestWithEndpoint:(NSString *)endpoint params:(NSDictionary *)params method:(NSString *)method;
- (NSURLRequest *)signRequest:(NSURLRequest *)request;


@end


@interface MONetworkConnection : NSObject<NSURLSessionDelegate>

+ (void)setRequestFactory:(id<MONetworkConnectionRequestFactory>)requestFactory;
+ (id<MONetworkConnectionRequestFactory>)requestFactory;

+ (instancetype)sendAsynchronousRequest:(NSURLRequest *)request
                                 mapper:(id<MOMapperProtocol>)mapper
                      connectionHandler:(MONetworkConnectionHandler)connectionHandler
                              onSuccess:(MONetworkConnectionSuccessHandler)onSuccessHandler
                                onError:(MONetworkConnectionErrorHandler)onSuccessHandler;

+ (instancetype)sendAsynchronousAPIRequestWithEndpoint:(NSString *)endpoint
                                             parmeters:(NSDictionary *)parameters
                                                method:(NSString *)method
                                     connectionHandler:(MONetworkConnectionHandler)connectionHandler
                                             onSuccess:(MONetworkConnectionSuccessHandler)successHandler
                                               onError:(MONetworkConnectionErrorHandler)errorHandler;


//Network and HTTP related properties
@property (nonatomic, strong) NSURLRequest *request;
@property (nonatomic, strong) NSHTTPURLResponse *response;

//Error properties
@property (nonatomic, strong) NSError *responseError;
@property (nonatomic, strong) NSError *mapperError;

//Data properties
@property (nonatomic, strong) NSData *responseData;
@property (nonatomic, strong) id parsedResponse;

//Other properties
@property (nonatomic, copy) MONetworkConnectionSuccessHandler successHandler;
@property (nonatomic, copy) MONetworkConnectionErrorHandler errorHandler;
@property (nonatomic, strong) id<MOMapperProtocol>mapper;
@property (nonatomic, assign) NSInteger numberOfAttempts;

///Indicates if the request needs an existing session. If YES an no session yet, then it is on put on hold. Defaults to YES.
@property (nonatomic, assign) BOOL requireSession;

- (void)start;
- (void)cancel;

@end

