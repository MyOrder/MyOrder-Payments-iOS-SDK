//
//  MOAmount.h
//  MyOrder
//
//  Created by Dmytro Andreikiv on 30/04/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSNumber+MOUtils.h"

@interface MOAmount : NSObject <NSCoding>

@property (nonatomic, copy) NSString * currency;
@property (nonatomic, strong) NSNumber * amount;

- (id)initWithDictionary:(NSDictionary *)data;

@end
