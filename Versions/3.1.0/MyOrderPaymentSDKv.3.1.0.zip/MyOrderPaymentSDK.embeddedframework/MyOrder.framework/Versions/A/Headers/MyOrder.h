//
//  MyOrder.h
//  MyOrder
//
//  Created by Taras Kalapun on 5/22/13.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#import "MOErrorCodes.h"
#import "MOTransaction.h"
#import "MOPaymentOperation.h"
#import "MOProgressHUD.h"
#import "MONetworkConnection.h"
#import "MOSession.h"
#import "MOUser.h"
#import "MOReceipt.h"

@class MyOrder;
@class MOTransactionViewController;
@class MOOperationViewController;

typedef CLLocation*(^MOLocationBlock)(void);
typedef void(^MOBlock)(void);
typedef void(^MOStatusBlock)(NSNumber *status);
typedef void(^MOResponseDictionaryBlock)(NSDictionary *response);
typedef void(^MOResponseArrayBlock)(NSArray *response);
typedef void(^MOResponseReceiptFiltersBlock)(MOReceiptFilters *response);
typedef void(^MOResponseUserBlock)(MOUser *user);
typedef void(^MOErrorBlock)(NSError *error);
typedef void(^MOViewControllerBlock)(UIViewController *vc);

@protocol  MOImageEditDispatcherDelegate <NSObject>

- (void)didRequestToEditImage:(UIImage*)image completion:(void (^)(UIImage*))completionBlock;

@end

@protocol MOTransactionProtocol;


typedef enum MyOrderEnvironment
{
    MyOrderEnvironmentNone,                 // No environment set
    MyOrderEnvironmentLive,                 // Live environment for production
    MyOrderEnvironmentTest,                 // Test environment
    MyOrderEnvironmentSandboxPlayground,    // Playground environment is a sandbox open for any third party
    MyOrderEnvironmentSandboxAcceptance,    // Sandbox environment for developing purposes (requires key)
    
    MyOrderEnvironmentSandboxCI,            // Sandbox environment for developing purposes (requires key)
    MyOrderEnvironmentOther,                // Other environment used only for automated tests or debuging
    MyOrderEnvironmentSandboxGreenhouse,    // Sandbox environment for developing purposes (requires key)
    MyOrderEnvironmentSandboxEngineRoom,
} MyOrderEnvironment;


/**
 * Notification sent through NSNotificationCenter when a session change happens. It includes logout.
 */
extern const NSString *MOSessionChangedNotification;
/**
 * Notification sent through NSNotificationCenter when a session is expired or invalid. Should not happen
 * unless a user logs in in a different device
 */
extern const NSString *MOSessionExpiredNotification;

/**
 * Notification sent through NSNotificationCenter when a user finished the wirecard migration process and confirmed he wants to go to automatic charge
 */
extern const NSString *MOWalletShouldShowAutomaticChargeNotification;

/**
 * Notification sent through NSNotificationCenter when a user adds or removes a loyalty card
 */
extern const NSString *MOLoyaltyCardsChangedNotification;
 

@interface MyOrder : NSObject

/**
 @name User defined properties
 */

/** In case you want to edit any picture that is being taken, you can conform to the MOImageEditDispatcherDelegate and set it. After taking an image, the delegate will be called to edit the image. Not part of the SDK itself as it is highly app dependant */

@property (nonatomic, strong) id<MOImageEditDispatcherDelegate> imageEditDelegate;

/** MyOrder environment to use. Use `MyOrderEnvironmentLive` for live or `MyOrderEnvironmentSandbox` for sandbox */
@property (nonatomic, assign) MyOrderEnvironment environment;

/** MyOrder api key to use. Also known as userId */
@property (nonatomic, copy) NSString *apiKey;

/** MyOrder api secret to use. Also known as password */
@property (nonatomic, copy) NSString *apiSecret;

/** Payment description to use in transaction operations that allows customization (Ex: iDeal). Defaults to app name */
@property (nonatomic, copy) NSString *defaultMerchantDescription;

/** URL Scheme used by the app. Required for allowing returning to the app after login, iDeal payments,... */
@property (nonatomic, copy) NSString *URLScheme;


/**
 @name Readonly properties
 */

/** List of available payment provider for a specific channel */
@property (nonatomic, copy, readonly) NSArray *availablePaymentProviders;

/** Returns the current transaction started with newTransactionForProvider: */
@property (nonatomic, strong, readonly) id<MOTransactionProtocol> currentTransaction;

/** List of available payment operations names in MyOrder library */
@property (nonatomic, copy, readonly) NSArray *availablePaymentOperations;

/** List of payment options configured by configureWithPaymentOptions: */
@property (nonatomic, copy, readonly) NSArray *configuredPaymentOperations;

/**
 Returns a BOOL indicating if the user is logged in
 */
@property (nonatomic, assign, readonly) BOOL isLoggedIn;
@property (nonatomic, assign, readonly) BOOL isLogging;

/**
 Returns a MyOrder session object
 */
@property (nonatomic, strong, readonly) MOSession *session;

/** Returns the current balance in euros of the primary wallet, or nil if there isn't one */
@property (nonatomic, strong, readonly) NSNumber *balance;

/** Returns the KYC level of the primary wallet, or nil if there isn't one */
@property (nonatomic, strong, readonly) NSNumber *kycLevel;

/** Returns the pending KYC level of the primary wallet, or nil if there isn't one */
@property (nonatomic, strong, readonly) NSNumber *pendingKycLevel;

/** Returns the wallet retrieved by updateBalanceOnSuccess:error. nil if the wallets have not been retrieved yet */
@property (nonatomic, strong, readonly, nullable) NSArray *wallets;

/** Returns the all kycLevels retrieved by updateBalanceOnSuccess:error. nil if the kycLevels have not been retrieved yet */
@property (nonatomic, strong, readonly) NSArray *kycLevels;

/** Returns the user retrieved by loadUserDetailOnSuccess:error:. nil if the userDetail have not been retrieved yet */
@property (nonatomic, strong, readonly) MOUser *user;

/** Returns the last receipts retrieved by updateReceiptsOnSuccess:error:. nil if the receipts have not been retrieved yet */
@property (nonatomic, strong, readonly) NSArray *receipts;

/** Used only to get last known location to be used when performing a payment */
@property (nonatomic, copy) MOLocationBlock locationBlock;

/**
 @name Generic methods
 */

/**
 @return Singleton MyOrder object.
 */
+ (instancetype)shared;


- (CLLocation *)currentLocation;

/**
 Customize available options
 @param operations Array of `NSString` payment operation types (as found in `MODefines.h`).
 */
- (void)configureWithPaymentOperations:(NSArray *)operations;

/**
 Get a particular payment provider instance based on the name, if present.
 @param providerName Name of provider
 @return Provider instance or nil
 */
- (id<MOPaymentProviderProtocol>)availablePaymentProviderInstanceWithName:(NSString *)providerName;


/**
 Get a particular payment provider that is configured for the wallet management
 @return Provider instance for wallet
 */
- (id<MOPaymentProviderProtocol>)availablePaymentProviderForWallet;

/**
 Create a new transaction for a payment provider
 @param providerName NSString of provider name.
 @returns New transaction instance
 */
- (id<MOTransactionProtocol>)newTransactionForProvider:(NSString *)providerName;


/**
 Returns the operation information related to a particular operation name
 @param operationName NSString of operation name.
 @returns NSDictionary with operation information for the particular name
 */
- (NSDictionary *)infoForOperation:(NSString *)operationName;


/**
 Returns a BOOL indicating if the URL has been handled by MyOrder. Some payment methods (like iDeal) require this method to be implemented.
 @param url URL received in `application:openURL:sourceApplication:annotation` method.
 @param sourceApplication Received in `application:openURL:sourceApplication:annotation` method.
 @param verificationSuccessBlock Callback for the case that the URL was for user verification and it succeeded
 @returns BOOL YES if the URL has been handled
 */
- (BOOL)handleURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication onVerificationSuccess:(dispatch_block_t)verificationSuccessBlock;

@end


@interface MyOrder (UI)

/**
 Creates and returns a UIViewController with the login flow. If user is logged in, executes the completionBlock immediatelly and returns nil
 @param completionBlock Completion block to execute when login finishes
 @returns UIViewController for login
 */
- (UIViewController *)loginViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock;


/**
 Creates and returns a UIViewController with the register flow. If user is logged in, executes the completionBlock immediatelly and returns nil
 @param completionBlock Completion block to execute when login finishes
 @returns UIViewController for login
 */
- (UIViewController *)registerViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock;


/**
 Creates and returns a UIViewController with change user email flow. If user verified new email, executes the completionBlock immediatelly and returns nil
 @param completionBlock Completion block to execute when new email is verified
 @returns UIViewController for changing email
 */
- (UIViewController *)changeEmailViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock;

/**
 Creates and returns a UIViewController with change user phone flow. If user verified new phone number, executes the completionBlock immediatelly and returns nil
 @param completionBlock Completion block to execute when new phone number is verified
 @returns UIViewController for changing/adding phone number
 */
- (UIViewController *)changePhoneViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock;
- (UIViewController *)changePhoneViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock cancellationBlock:(MOViewControllerBlock)cancellationBlock;


/**
 Creates and returns a UIViewController with migrate to Wirecard flow, executes the completionBlock on migration
 @param completionBlock Completion block to execute when migrate to vias is done
 @param cancellationBlock Cancellation block when dismiss button touched
 @param notAcceptedSmartWalletTermsBlock if user not accepted smart wallet terms
 @returns UIViewController for changing/adding phone number
 */
- (UIViewController *)migrateToWireCardViewControllerCompletionBlock:(MOViewControllerBlock)completionBlock cancellationBlock:(MOBlock)cancellationBlock notAcceptedSmartWalletTermsBlock:(MOBlock)notAcceptedSmartWalletTermsBlock;

/**
 Creates and returns a UIViewController with migrate to Wirecard flow, executes the completionBlock on migration
 @param completionBlock Completion block to execute when migrate to vias is done
 @returns UIViewController for wirecard available functions, this must be shown if user has not enable wirecard
 */
- (UIViewController *)wireCardTermsViewControllerCompletionBlock:(MOViewControllerBlock)completionBlock;

/**
 Creates and returns a UIViewController with the verification flow. Verification is required to perform certain actions and it is done validating a PIN code
 @param completionBlock Completion block to execute when login finishes
 @returns UIViewController for login
 */
- (UIViewController *)verifyViewControllerWithCompletionBlock:(MOViewControllerBlock)completionBlock;


/**
 Returns the transaction UIViewController related to a particular provider. If the controller is meant to be used for payments, you need to pass the MOOrder to the  vc.transaction.order, otherwise the operation will try to fill your wallet
 @param providerName NSString of provider name.
 @returns UIViewController for specific transaction
 */
- (MOTransactionViewController *)transactionViewControllerForProvider:(NSString *)providerName;


/**
 Returns the MOOperationViewController related to a particular payment operation
 @param operationName NSString of operation name.
 @returns UIViewController for specific transaction
 */
- (MOOperationViewController *)operationViewControllerForPaymentOperation:(NSString *)operationName;


/**
 Creates and returns a UIViewController with the users wallet and payment methods. Note that some payment providers can be used without login as long as the mobile phone is set
 @param forceLogin If set to YES and the user is not logged in, it will return the login controller instead
 @returns UIViewController for wallet
 */
- (UIViewController *)walletViewControllerWithLogin:(BOOL)forceLogin;

/**
 Creates and returns a UIViewController for selecting payment options for a specific order. Note that some payment providers can be used without login as long as the mobile phone is set
 @param order MOOrder with the purchase details
 @param forceLogin If set to YES and the user is not logged in, it will return the login controller instead
 @param highlightedOperationName When set the specified operation will be highlighted
 @param completionBlock Block executed when the order has been payed
 @returns UIViewController for specific order purchase
 */
- (UIViewController *)paymentViewControllerForOrder:(MOOrder *)order forceLogin:(BOOL)forceLogin highlightedOperationName:(NSString*)highlightedOperationName onCompletion:(dispatch_block_t)completionBlock;

// Convenience for when a highlighted operation is not required
- (UIViewController *)paymentViewControllerForOrder:(MOOrder *)order forceLogin:(BOOL)forceLogin onCompletion:(dispatch_block_t)completionBlock;


/**
 Creates and returns a UIViewController with the receipts list of the user
 @returns UIViewController for receipts
 */
- (UIViewController *)receiptsViewController;


@end


@interface MyOrder (API)

/**
 Starts a new registration in the device with provided credentials. Registration is not complete until user has finished verifying
 the account by entering the received PIN
 @param username User credentials. It can be a phone or email.
 @param firstName First name
 @param lastName Last Name
 @param birthDate Date of birth in format 1985-10-18
 @param subscribeNews Bool indicating if the user should receive newsletters from MyOrder
 @param wireCard Bool indicating if user has accepted wirecard T&C
 @param proximityPayment Bool indicating if we should register for the double card program.
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)registerWithUsername:(NSString *)username
                   firstName:(NSString *)firstName
                    lastName:(NSString *)lastName
                   birthDate:(NSString *)birthDate
               subscribeNews:(BOOL)subscribeNews
                    wireCard:(BOOL)wireCard
            proximityPayment:(BOOL)proximityPayment
                   onSuccess:(MOBlock)block
                       error:(MOErrorBlock)errorBlock;

/**
 Refreshes a current user's session. Needs to be called when user updateds email or phone number
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)refreshSessionOnSuccess:(MOBlock)block
                          error:(MOErrorBlock)errorBlock;


/**
 Verifies the existing login by confirming the PIN code received.
 @param username User credentials. It can be a phone or email.
 @param pin Received PIN code
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)verifyRegistrationWithUsername:(NSString *)username andPin:(NSString *)pin onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Requests a new PIN number to verify the registered account
 @param block Block executed when the request as been sent
 @param errorBlock Block executed when an error occurs
 */
- (void)requestVerificationCodeOnSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;

/**
 Requests a verification code to be sent to a given user to confirm their account
 @param username Either the email address or phone number of the user to be verified
 @param block Block executed when the user has been sent a verification code
 @param errorBlock Block executed when an error occurs
 */
- (void)requestVerificationCodeWithUsername:(NSString *)username
                                  onSuccess:(MOBlock)block
                                      error:(MOErrorBlock)errorBlock;

/**
 Requests a new PIN number with provided credentials.
 @param username User credentials. It can be a phone or email.
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)requestLoginPinWithUsername:(NSString *)username onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Verifies the existing login by confirming the PIN code received.
 @param username User credentials. It can be a phone or email.
 @param pin Received PIN code
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)loginWithUsername:(NSString *)username andPin:(NSString *)pin onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Updates email or phonenumber with verification.
 @param username User credentials. It can be a phone or email.
 @param block Block executed when the prelogin finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)changeLoginDetail:(NSString *)username onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;



/**
 Load user profile details
 @param block Block executed when the user detail loading finishes successfully, providing an `MOUser` object
 @param errorBlock Block executed when an error occurs
 */
- (void)loadUserDetailOnSuccess:(MOResponseUserBlock)block error:(MOErrorBlock)errorBlock;



/**
 Update a user's profile details
 @param firstName User's first name
 @param lastName User's last name
 @param birthDate User's birth date, in `dd-MM-yyyy` format.
 @param block Block executed when the update finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)updateUserWithFirstName:(NSString *)firstName lastName:(NSString *)lastName birthDate:(NSString *)birthDate onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Update an existing user address
 @param address If it's a previous address being modified, pass it here. Pass `nil` to create a new address.
 @param street Street
 @param houseNumber House number
 @param zipCode ZIP Code
 @param city City
 @param block Block executed when the update finishes successfully
 @param errorBlock Block executed when an error occurs
 */

- (void)updateUserAddress:(MOAddresses *)address WithStreet:(NSString *)street houseNumber:(NSString *)houseNumber zipCode:(NSString *)zipCode city:(NSString *)city onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;

/**
 Fetch the user's newsletter status.
 @param block Block executed on success, passed an NSNumber whose boolValue gives you status.
 @param errorBlock Block executed when an error occurs
 */
- (void)fetchNewsletterStatusOnSuccess:(MOStatusBlock)block error:(MOErrorBlock)errorBlock;

/**
 Subscribe or unsubscribe to the MyOrder newsletter.
 @param subscribe Whether the user wishes to be subscribed to the newsletter
 @param block Block executed on success
 @param errorBlock Block executed when an error occurs
 */
- (void)subscribeToNewsletter:(BOOL)subscribe onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;

/**
 Migrate To Vias (Wirecard)
 @param proximityPayment Means double card program
 @param transferBalance transfer Minitix balance to Wirecard
 @param newsletterOrNil A `BOOL` wrapped in an `NSNumber` to indicate whether the user should be subscribed (`@(YES)`), unsubscribed (`@(NO)`) or whether his subscription status should remain unchanged (`nil`).
 @param block Block executed when the operation finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)migrateToViasWithProximityPayment:(BOOL)proximityPayment transferBalance:(BOOL)transferBalance newsletter:(NSNumber*)newsletterOrNil onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;

/**
 Create SmartWallet (Wirecard)
 @param proximityPayment Means double card program
 @param block Block executed when the operation finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)createWalletWithProximityPayment:(BOOL)proximityPayment onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;

/**
 Upload Document for KYC
 @param passport Image representation of passport
 @param bill Image representation of proof-of-address, usually a utility bill
 @param block Block executed when the upload operation finishes successfully
 @param errorBlock Block executed when an error occurs
 */
- (void)uploadIdentificationForKYCWithPassportDocument:(UIImage *)passport billDocument:(UIImage *)bill onSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Logs out the user and deletes saved credentials
 @param block Block executed when the logout finishes successfully 
 @param errorBlock Block executed when an error occurs
 */
- (void)logoutOnSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock;


/**
 Updates the user's balance
 @param block Block executed when the wallets are loaded. Contains parsed MOWallet
 @param errorBlock Block executed when an error occurs
 */
- (void)updateBalanceOnSuccess:(MOResponseArrayBlock)block error:(MOErrorBlock)errorBlock;


/** @name Getting transaction history */

/**
 Loads Purchase history and returns MOReceipts
 @param block Block executed when the history is loaded. Contains parsed MOReceipts
 @param errorBlock Block executed when an error occurs
 */
- (void)updateReceiptsOnSuccess:(MOResponseArrayBlock)block error:(MOErrorBlock)errorBlock;

/**
 Loads Purchase history and returns MOReceipts
 @param offset The offset in history from which server should return history list
 @param limit The number of items in list which server should return
 @param statuses Statuses to filter receipts
 @param merchantTypes Merchant types to filter receipts
 @param licensePlates License plates to filter receipts
 @param fromDate Beginning of date range to filter receipts
 @param toDate End of date range to filter receipts
 @param searchQuery Query string to filter receipts
 @param block Block executed when the history is loaded. Contains parsed MOReceipts
 @param errorBlock Block executed when an error occurs
 */
- (void)receiptsWithOffset:(NSUInteger)offset
                     limit:(NSUInteger)limit
        filteredByStatuses:(NSArray<MOReceiptStatusFilter*>*)statuses
             merchantTypes:(NSArray<MOReceiptMerchantTypeFilter*>*)merchantTypes
             licensePlates:(NSArray<MOReceiptLicensePlateFilter*>*)licensePlates
                  fromDate:(NSDate*)fromDate
                    toDate:(NSDate*)toDate
               searchQuery:(NSString*)searchQuery
                 onSuccess:(MOResponseArrayBlock)block error:(MOErrorBlock)errorBlock;


/**
 Loads merchant types and license plates that it will be appropriate to provide as filtering
 options anywhere where a list of the user's past transactions/receipts are displayed.
 @param block Block executed when the filters are loaded
 @param errorBlock Block executed when an error occurs
 */
- (void)receiptFiltersOnSuccess:(MOResponseReceiptFiltersBlock)block error:(MOErrorBlock)errorBlock;

/**
 Causes the server to email a PDF report on the chosen receipts to the user.
 @param receipts Receipts to specifically include in the report
 @param receipts Receipts to specifically exclude in the report (all others matching the filter parameters will be included)
 @param merchantTypes Merchant types to filter receipts
 @param licensePlates License plates to filter receipts
 @param fromDate Beginning of date range to filter receipts
 @param toDate End of date range to filter receipts
 @param searchQuery Query string to filter receipts
 @param block Block executed when the history is loaded. Contains parsed MOReceipts
 @param errorBlock Block executed when an error occurs
 */
- (void)emailReportToUserWithReceipts:(NSArray<MOReceipt*>*)receipts
                     excludedReceipts:(NSArray<MOReceipt*>*)excludedReceipts
                        merchantTypes:(NSArray<MOReceiptMerchantTypeFilter*>*)merchantTypes
                        licensePlates:(NSArray<MOReceiptLicensePlateFilter*>*)licensePlates
                             fromDate:(NSDate*)fromDate
                               toDate:(NSDate*)toDate
                          searchQuery:(NSString*)searchQuery
                            onSuccess:(MOResponseDictionaryBlock)block
                                error:(MOErrorBlock)errorBlock;

/**
 *  Forces the reload of keychain data. You should not need to call this method
 *  explicitely unless you manually change the SDK properties (not recommended)
 *  or you have a background app/extension that needs to get synchronized with
 *  changes in the main app
 */
- (void)reloadKeychainData;

- (NSString *)getWalletCurrencySimbol;


/**
 *  Adds a certificate's public key to the list of pinned keys.
 *  A secure connection will only be allowed if the certificate's public key matches a key in the list
 *  @param key The certificates public key to pin
 */
- (void)addPinnedKey:(NSString *)key;

/**
 *  Removes a certificate's public key from the list of pinned keys.
 *  If the list becomes empty, all connections will be allowed
 *  @param key The certificates public key to remove
 */
- (void)removePinnedKey:(NSString *)key;

/**
 *  Retrieve the list of public keys to pin against.
 *  If this list is empty, all connections will be allowed.
 *  If this list contains one or more keys, a secure connection will only be allowed if the public key from the connection's certificate matches any key in the list
 */
- (NSArray *)getPinnedKeys;

@end


@interface MyOrder (Others)

+ (NSString *)localizedStringForKey:(NSString *)key value:(NSString *)value table:(NSString *)tableName NS_FORMAT_ARGUMENT(1);
+ (void)setSharedInstance:(MyOrder *)myOrder;
+ (NSString *)versionIdentifier;
- (NSString *)sessionId;
- (void)setSession:(MOSession *)session save:(BOOL)save;

@end


@interface MyOrder (Deprecated)
- (void)loginOnSuccess:(MOBlock)block error:(MOErrorBlock)errorBlock __deprecated_msg("Method no longer supported. Password can not be stored. Remove this call");
- (BOOL)handleURL:(NSURL *)url __deprecated_msg("Method no longer supported. Use handleURL:sourceApplication:onVerificationSuccess: instead");
- (BOOL)handleURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication __deprecated_msg("Method no longer supported. Use handleURL:sourceApplication:onVerificationSuccess: instead");
- (void)loadWalletHistoryOnSuccess:(MOResponseDictionaryBlock)block error:(MOErrorBlock)errorBlock __deprecated_msg("Method not longer supported.");
@end




