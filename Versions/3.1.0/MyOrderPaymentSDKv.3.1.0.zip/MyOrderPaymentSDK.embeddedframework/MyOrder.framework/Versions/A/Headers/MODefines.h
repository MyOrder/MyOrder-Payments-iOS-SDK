//
//  MODefines.h
//  MyOrder
//
//  Created by Taras Kalapun on 04-09-2013.
//  Copyright (c) 2013 Xaton. All rights reserved.
//

#import "MyOrder.h"

#define MOLocalizedString(key, comment) \
[MyOrder localizedStringForKey:(key) value:@"" table:nil]

#define MOWirecardTermsAndConditionsURLString   @"https://www.myorder.nl/voorwaarden/Wirecard_MyOrder_Terms_and_Conditions.pdf"
#define MOTermsAndConditionsURLString           @"https://www.myorder.nl/voorwaarden_myorder"
#define MOPrivacyPolicyURLString                @"https://www.myorder.nl/privacy_policy_myorder"

#if DEBUG
#define MOLog(...)  NSLog(@"MOLog: %s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#define MOLogDebug(...)  NSLog(@"MODebug: %s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#define MOLogInfo(...)  NSLog(@"MOInfo: %s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#define MOLogWarning(...)  NSLog(@"MOWarning: %s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#define MOLogError(...)  NSLog(@"MOError: %s %@", __PRETTY_FUNCTION__, [NSString stringWithFormat:__VA_ARGS__])
#else
#define MOLog(...)  do { } while(0)
#define MOLogDebug(...)  do { } while(0)
#define MOLogInfo(...)  do { } while(0)
#define MOLogWarning(...)  do { } while(0)
#define MOLogError(...)  do { } while(0)
#endif



#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

#define OperationAutomaticCharge @"AutomaticCharge"
#define OperationPayYourFriend @"PayYourFriends"
#define OperationWithDrawFromWallet @"WithdrawFromWallet"
#define OperationIncreaseKYCLevel @"IncreaseKYCLevel"
