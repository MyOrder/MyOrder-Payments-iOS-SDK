//
//  MOReceiptsViewController.h
//  MyOrder
//
//  Created by Taras Kalapun on 6/6/13.
//  Copyright (c) 2013 Xaton. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MOViewController.h"
#import "MOReceipt.h"

@protocol MOReceiptsViewControllerDelegate <NSObject>

@optional
- (void)willStartLoading;
- (void)didEndLoading;

@end

@interface MOReceiptsViewController : MOViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong, nullable) IBOutlet UITableView *tableView;
@property (nonatomic, strong, nullable) IBOutlet UIRefreshControl *refreshControl;

@property (nonatomic, strong, nonnull) NSMutableArray *receipts;
@property (nonatomic, readonly, nonnull) NSArray *selectedReceipts;
@property (nonatomic, readonly, nonnull) NSArray *deselectedReceipts; // All receipts downloaded but not selected

@property (nonatomic) BOOL allowSelection;
@property (nonatomic) BOOL groupReceiptsByWeek;

@property (nonatomic, copy, nullable) NSDate *filteredFromDate;
@property (nonatomic, copy, nullable) NSDate *filteredToDate;
@property (nonatomic, copy, nullable) NSArray<MOReceiptStatusFilter*> *filteredStatuses;
@property (nonatomic, strong, nullable) NSArray<MOReceiptLicensePlateFilter*> *filteredLicensePlates;
@property (nonatomic, strong, nullable) NSArray<MOReceiptMerchantTypeFilter*> *filteredMerchantTypes;
@property (nonatomic, strong, nullable) NSString *searchQuery;

@property (nonatomic, weak, nullable) id<MOReceiptsViewControllerDelegate> delegate;

- (void)refresh;

- (void)selectAllReceipts;
- (void)clearSelectedReceipts;
- (void)addReceiptsToSelection:(nonnull NSArray*)receipts;

- (nullable MOReceipt*)receiptAtIndexPath:(nonnull NSIndexPath*)indexPath;

// Override point: for example while in a search we should prevent
- (BOOL)shouldAutomaticallyDownloadNextPage;

// Call to get a nice localised string describing the filters currently applied
- (nonnull NSString*)stringWithFiltersDescription;

- (void)willStartLoading;
- (void)didEndLoadingAddingReceipts:(nullable NSArray*)receipts;

- (void)didChangeSelection; // default reloads table; subclasses should call through

@end
