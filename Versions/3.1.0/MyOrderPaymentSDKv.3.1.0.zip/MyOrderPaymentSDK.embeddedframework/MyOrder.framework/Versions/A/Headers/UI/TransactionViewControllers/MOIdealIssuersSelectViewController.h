//
//  MOIdealIssuersSelectViewController.h
//  MyOrder
//
//  Created by Angel Garcia on 20/03/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import "MOViewController.h"
@class MOIdealTransaction;

@interface MOIdealIssuersSelectViewController : MOViewController

@property (nonatomic, strong) MOIdealTransaction *transaction;

@end
