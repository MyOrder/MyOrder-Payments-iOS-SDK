//
//  NSError+MOError.h
//  MyOrder
//
//  Created by Angel Garcia on 10/10/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSError (MOError)

- (NSString *)MO_formattedDescription;

@end
