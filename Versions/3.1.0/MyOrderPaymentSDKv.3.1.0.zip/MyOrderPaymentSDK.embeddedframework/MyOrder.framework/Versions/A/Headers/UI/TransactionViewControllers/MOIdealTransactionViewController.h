//
//  MOIdealTransactionViewController.h
//  MyOrder
//
//  Created by Taras Kalapun on 5/29/13.
//
//

#import "MOTransactionViewController.h"

@interface MOIdealTransactionViewController : MOTransactionViewController
@property (nonatomic, copy) void (^dismissBlock)();
@end
