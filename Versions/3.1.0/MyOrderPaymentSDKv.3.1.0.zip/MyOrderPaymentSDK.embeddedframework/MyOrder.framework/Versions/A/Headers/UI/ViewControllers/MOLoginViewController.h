//
//  MOLoginViewController.h
//  MyOrder
//
//  Created by Angel Garcia on 5/27/13.
//
//

#import "MOViewController.h"

/** Login controller. Presents a login screen with remember and registration options */
@interface MOLoginViewController : MOViewController

/** Completion block called when login is completed */
@property (nonatomic, copy) void (^completionBlock)(UIViewController *controller);

@end
