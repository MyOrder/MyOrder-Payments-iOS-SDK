//
//  MOWallet.h
//  MyOrder
//
//  Created by Angel Vasa on 27/08/15.
//  Copyright (c) 2015 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MOWallet : NSObject


@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *currency;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSNumber *balance;
@property (nonatomic, copy) NSNumber *yearLimit;
@property (nonatomic, copy) NSNumber *remainingLimit;
@property (nonatomic, copy) NSNumber *kycLevel;
@property (nonatomic, copy) NSNumber *pendingKycLevel;
@property (nonatomic) BOOL active;
@property (atomic, assign) BOOL isMTXWallet;
@property (nonatomic, copy) NSString *ccLink;
@property (nonatomic, copy) NSString * statusMessage;


- (id)initWithDictionary:(NSDictionary *)wallet;

@end



@interface MOKYCLevel : NSObject

@property (nonatomic, copy) NSNumber *level;
@property (nonatomic, copy) NSNumber *yearLimit;
@property (atomic, assign) BOOL requiresCompleteProfile;
@property (atomic, assign) BOOL requiresDocumentUpload;

- (id)initWithDictionary:(NSDictionary *)kycLevel;

@end
