//
//  MOPaymentOperation.h
//  MyOrder
//
//  Created by Angel Garcia on 24/04/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MOPaymentOperation;

/**
 Consts used for the payment option info key
 */
extern const NSString *MOPaymentOperationName;
extern const NSString *MOPaymentOperationDescription;
extern const NSString *MOPaymentOperationCanBeOpen;
extern const NSString *MOPaymentOperationAllowsWalletOperation;
extern const NSString *MOPaymentOperationAllowsOrderOperation;
extern const NSString *MOPaymentOperationPriority;
extern const NSString *MOPaymentOperationSupportedVersions;

typedef void(^MOOperationBlock)(MOPaymentOperation *operation, id response);
typedef void(^MOOperationErrorBlock)(MOPaymentOperation *operation, NSError *error);

typedef enum {
    MOPaymentOperationStatusStarted,
    MOPaymentOperationStatusVerificationRequired,
    MOPaymentOperationStatusVerificationRequiredForSave,
    MOPaymentOperationStatusSaveRequired,
    MOPaymentOperationStatusFinished
} MOPaymentOperationStatus;


/**
 *  Payment operations are extra actions a user can perform in his wallet. For example, setting autoloading properties
 *  or transfering money to a friend. The MyOrder engine will automatically look for any subclass of MOPaymentOperation 
 *  during startup. Note that the nature of the payment operations is very concrete to each individual case, so custom 
 *  actions will be required on each case to complete them. Check the particular subclasses for more information
 */
@interface MOPaymentOperation : NSObject

@property (nonatomic, assign) MOPaymentOperationStatus status;
@property (nonatomic, copy) NSString *transactionId;

/**
 Returns the payment option info dictionary
 @return dictionary with option information (name, description, allows wallet,...)
 */
+ (NSDictionary *)info;

/**
 Returns the operation name
 @return string with provider name (ex: PayYourFriends)
 */
+ (NSString *)operationName;

/**
 Returns an array of supported MyOrder versions
 @return Array of versionIdentifiers. Example @[@"V1", @"V2"]
 */
+ (NSArray *)supportedVersions;


/**
 Start the operation
 @param completionBlock Block that will be called on success
 @param errorBlock Block called on error
 */
- (void)executeOnCompletion:(MOOperationBlock)completionBlock onError:(MOOperationErrorBlock)errorBlock;


/**
 *  Verifies the operation by confirming the action with the SMS code received
 *
 *  @param code            SMS code
 *  @param completionBlock Completion block called on success
 *  @param errorBlock      Error block if fails
 */
- (void)verifyWithCode:(NSString *)code onCompletion:(MOOperationBlock)completionBlock onError:(MOOperationErrorBlock)errorBlock;



@end