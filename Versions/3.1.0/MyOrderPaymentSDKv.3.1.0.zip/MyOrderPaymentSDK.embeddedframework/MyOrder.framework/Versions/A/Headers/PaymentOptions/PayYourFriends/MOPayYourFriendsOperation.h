//
//  MOPayYourFriendsOperation.h
//  MyOrder
//
//  Created by Angel Garcia on 24/04/14.
//  Copyright (c) 2014 Xaton. All rights reserved.
//

#import "MOPaymentOperation.h"
#import <CoreGraphics/CoreGraphics.h>


/**
 *  Makes a payment to a friend. This operation requires confirmation of SMS code
 */
@interface MOPayYourFriendsOperation : MOPaymentOperation

@property (nonatomic, copy) NSString *mobileNumber;
@property (nonatomic, assign) CGFloat amount;
@property (nonatomic, copy) NSString *details;

@end
