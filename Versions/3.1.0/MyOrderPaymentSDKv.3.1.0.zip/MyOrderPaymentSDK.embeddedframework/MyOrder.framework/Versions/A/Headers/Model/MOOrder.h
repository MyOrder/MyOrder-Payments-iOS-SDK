//
//  MOOrder.h
//  MyOrder
//
//  Created by Taras Kalapun on 5/29/13.
//
//

#import <Foundation/Foundation.h>

@class MOAmount;

@interface MOOrder : NSObject

/**
 Order Id given by the external system behind the transaction. Required
 */
@property (nonatomic, copy) NSString *externalOrderId;


/**
 Internal Order Id used by MyOrder. If provided, payment will be done with previous fulfillment data. Optional
 */
@property (nonatomic, copy) NSString *orderId;


/**
 The items to be ordered. Array of MOOrderItem
 */
@property (nonatomic, strong, readonly) NSArray *items;


/**
 The price of the order, must correspond with the total price of the given items
 If not set, will return the sum of all items and quantities
 */
@property (nonatomic, strong) MOAmount *price;


/**
 Add an item to the order
 @param name Name of the item
 @param price Price of the item in euros
 @param quantity Number of items
 */
- (void)addItemWithName:(NSString *)name price:(MOAmount *)price quantity:(NSUInteger)quantity;

@end

@interface MOOrder (Networking)
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
- (NSDictionary *)toDictionary;
@end

@interface MOOrderItem : NSObject
@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) NSUInteger quantity;
@property (nonatomic, strong) MOAmount *price;
@end

@interface MOOrderItem (Networking)
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
- (NSDictionary *)toDictionary;
@end
